-- C.W.B Japan Car Import: secure Supabase database setup
-- Run once in Supabase SQL Editor. This does NOT modify existing C.W.B tables.
-- CEO role is read from public.cwb_profiles.role_id -> public.cwb_roles.name = 'CEO'.

create extension if not exists pgcrypto;

create or replace function public.cwb_japan_is_active_user()
returns boolean
language sql stable security definer
set search_path = public, pg_temp
as $$
  select exists (
    select 1 from public.cwb_profiles p
    where p.id = auth.uid() and coalesce(p.active, false) = true
  );
$$;

create or replace function public.cwb_japan_is_ceo()
returns boolean
language sql stable security definer
set search_path = public, pg_temp
as $$
  select exists (
    select 1
    from public.cwb_profiles p
    join public.cwb_roles r on r.id = p.role_id
    where p.id = auth.uid()
      and coalesce(p.active, false) = true
      and upper(trim(coalesce(r.name, ''))) = 'CEO'
  );
$$;

revoke all on function public.cwb_japan_is_active_user() from public, anon;
revoke all on function public.cwb_japan_is_ceo() from public, anon;
grant execute on function public.cwb_japan_is_active_user() to authenticated;
grant execute on function public.cwb_japan_is_ceo() to authenticated;

create table if not exists public.cwb_japan_import_orders (
  id uuid primary key default gen_random_uuid(),
  order_no text not null unique default ('CWB-JI-' || to_char(timezone('Africa/Bujumbura', now()), 'YYYYMMDD') || '-' || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 6))),
  customer text not null,
  phone text,
  make text not null,
  year integer,
  photo_url text,
  vin text,
  supplier text,
  price numeric(12,2) not null default 0 check (price >= 0),
  bank_fee numeric(12,2) not null default 0 check (bank_fee >= 0),
  shipping numeric(12,2) not null default 0 check (shipping >= 0),
  clearing numeric(12,2) not null default 0 check (clearing >= 0),
  commission_standard numeric(12,2) not null default 100 check (commission_standard = 100),
  commission_discount numeric(12,2) not null default 0 check (commission_discount >= 0 and commission_discount <= 100),
  discount_reason text,
  commission_final numeric(12,2) generated always as (commission_standard - commission_discount) stored,
  vehicle_status text not null default 'Ordered' check (vehicle_status in ('Ordered','Purchased','Shipped','Arrived in Burundi','Delivered')),
  dhl_status text not null default 'Not dispatched' check (dhl_status in ('Not dispatched','In transit','Received in Burundi')),
  dhl_received_at timestamptz,
  notes text,
  created_by uuid not null default auth.uid() references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint cwb_japan_discount_reason_required check (commission_discount = 0 or nullif(trim(coalesce(discount_reason,'')), '') is not null)
);

create table if not exists public.cwb_japan_customer_payments (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.cwb_japan_import_orders(id) on delete restrict,
  amount numeric(12,2) not null check (amount > 0),
  method text not null,
  reference text,
  status text not null default 'PENDING' check (status in ('PENDING','CONFIRMED','REJECTED')),
  claimed_by uuid not null default auth.uid() references auth.users(id),
  claimed_at timestamptz not null default now(),
  confirmed_by uuid references auth.users(id),
  confirmed_at timestamptz,
  rejected_by uuid references auth.users(id),
  rejected_at timestamptz,
  rejection_reason text,
  created_at timestamptz not null default now(),
  constraint cwb_japan_payment_confirmation_fields check (
    (status = 'PENDING' and confirmed_by is null and confirmed_at is null and rejected_by is null and rejected_at is null)
    or (status = 'CONFIRMED' and confirmed_by is not null and confirmed_at is not null and rejected_by is null and rejected_at is null)
    or (status = 'REJECTED' and confirmed_by is null and confirmed_at is null and rejected_by is not null and rejected_at is not null)
  )
);

create table if not exists public.cwb_japan_commission_receipts (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.cwb_japan_import_orders(id) on delete restrict,
  amount numeric(12,2) not null check (amount > 0),
  reference text,
  received_at timestamptz not null default now(),
  confirmed_by uuid not null references auth.users(id),
  created_at timestamptz not null default now()
);

create index if not exists cwb_japan_orders_created_at_idx on public.cwb_japan_import_orders(created_at desc);
create index if not exists cwb_japan_payments_order_idx on public.cwb_japan_customer_payments(order_id, claimed_at desc);
create index if not exists cwb_japan_commission_receipts_order_idx on public.cwb_japan_commission_receipts(order_id, received_at desc);

alter table public.cwb_japan_import_orders enable row level security;
alter table public.cwb_japan_customer_payments enable row level security;
alter table public.cwb_japan_commission_receipts enable row level security;

-- Authenticated active C.W.B users may read shared import records.
drop policy if exists cwb_japan_orders_select_active on public.cwb_japan_import_orders;
create policy cwb_japan_orders_select_active on public.cwb_japan_import_orders
  for select to authenticated using (public.cwb_japan_is_active_user());

drop policy if exists cwb_japan_orders_insert_active on public.cwb_japan_import_orders;
create policy cwb_japan_orders_insert_active on public.cwb_japan_import_orders
  for insert to authenticated with check (public.cwb_japan_is_active_user() and created_by = auth.uid());

drop policy if exists cwb_japan_orders_update_active on public.cwb_japan_import_orders;
create policy cwb_japan_orders_update_active on public.cwb_japan_import_orders
  for update to authenticated using (public.cwb_japan_is_active_user()) with check (public.cwb_japan_is_active_user());

-- Workers may submit payment claims but cannot update, confirm, or reject them directly.
drop policy if exists cwb_japan_payments_select_active on public.cwb_japan_customer_payments;
create policy cwb_japan_payments_select_active on public.cwb_japan_customer_payments
  for select to authenticated using (public.cwb_japan_is_active_user());
drop policy if exists cwb_japan_payments_insert_claim on public.cwb_japan_customer_payments;
create policy cwb_japan_payments_insert_claim on public.cwb_japan_customer_payments
  for insert to authenticated with check (
    public.cwb_japan_is_active_user()
    and claimed_by = auth.uid()
    and status = 'PENDING'
    and confirmed_by is null and confirmed_at is null
    and rejected_by is null and rejected_at is null
  );

-- Only the CEO can read commission receipts. Writes occur through the protected RPC below.
drop policy if exists cwb_japan_commission_select_ceo on public.cwb_japan_commission_receipts;
create policy cwb_japan_commission_select_ceo on public.cwb_japan_commission_receipts
  for select to authenticated using (public.cwb_japan_is_ceo());

-- Least-privilege grants: discount and commission-payment fields are not directly writable by clients.
revoke all on public.cwb_japan_import_orders from anon, authenticated;
grant select on public.cwb_japan_import_orders to authenticated;
grant insert (customer, phone, make, year, photo_url, vin, supplier, price, bank_fee, shipping, clearing, vehicle_status, dhl_status, notes) on public.cwb_japan_import_orders to authenticated;
grant update (customer, phone, make, year, photo_url, vin, supplier, price, bank_fee, shipping, clearing, vehicle_status, dhl_status, dhl_received_at, notes, updated_at) on public.cwb_japan_import_orders to authenticated;

revoke all on public.cwb_japan_customer_payments from anon, authenticated;
grant select on public.cwb_japan_customer_payments to authenticated;
grant insert (order_id, amount, method, reference) on public.cwb_japan_customer_payments to authenticated;

revoke all on public.cwb_japan_commission_receipts from anon, authenticated;
grant select on public.cwb_japan_commission_receipts to authenticated;

-- CEO-only RPC: authorize a commission discount, with a reason and audit trail in the order row.
create or replace function public.cwb_japan_authorize_discount(p_order_id uuid, p_discount numeric, p_reason text)
returns public.cwb_japan_import_orders
language plpgsql security definer
set search_path = public, pg_temp
as $$
declare v_order public.cwb_japan_import_orders;
begin
  if not public.cwb_japan_is_ceo() then raise exception 'Only the C.W.B CEO may authorize a commission discount'; end if;
  if p_discount is null or p_discount < 0 or p_discount > 100 then raise exception 'Discount must be between 0 and 100'; end if;
  if p_discount > 0 and nullif(trim(coalesce(p_reason,'')), '') is null then raise exception 'A reason is required for a discount'; end if;
  update public.cwb_japan_import_orders
    set commission_discount = p_discount, discount_reason = nullif(trim(coalesce(p_reason,'')), ''), updated_at = now()
    where id = p_order_id returning * into v_order;
  if not found then raise exception 'Vehicle order not found'; end if;
  return v_order;
end;
$$;

-- CEO-only RPC: confirm a customer's payment claim after checking the real bank/mobile-money/cash record.
create or replace function public.cwb_japan_confirm_customer_payment(p_payment_id uuid)
returns public.cwb_japan_customer_payments
language plpgsql security definer
set search_path = public, pg_temp
as $$
declare v_payment public.cwb_japan_customer_payments;
begin
  if not public.cwb_japan_is_ceo() then raise exception 'Only the C.W.B CEO may confirm customer payments'; end if;
  update public.cwb_japan_customer_payments
    set status = 'CONFIRMED', confirmed_by = auth.uid(), confirmed_at = now()
    where id = p_payment_id and status = 'PENDING'
    returning * into v_payment;
  if not found then raise exception 'Pending payment claim not found or already processed'; end if;
  return v_payment;
end;
$$;

create or replace function public.cwb_japan_reject_customer_payment(p_payment_id uuid, p_reason text default null)
returns public.cwb_japan_customer_payments
language plpgsql security definer
set search_path = public, pg_temp
as $$
declare v_payment public.cwb_japan_customer_payments;
begin
  if not public.cwb_japan_is_ceo() then raise exception 'Only the C.W.B CEO may reject customer payment claims'; end if;
  update public.cwb_japan_customer_payments
    set status = 'REJECTED', rejected_by = auth.uid(), rejected_at = now(), rejection_reason = nullif(trim(coalesce(p_reason,'')), '')
    where id = p_payment_id and status = 'PENDING'
    returning * into v_payment;
  if not found then raise exception 'Pending payment claim not found or already processed'; end if;
  return v_payment;
end;
$$;

-- CEO-only RPC: commission can be received only after DHL documents arrive in Burundi.
-- Partial receipts are supported; a receipt cannot exceed the remaining commission due.
create or replace function public.cwb_japan_record_commission_receipt(p_order_id uuid, p_amount numeric, p_reference text default null)
returns public.cwb_japan_commission_receipts
language plpgsql security definer
set search_path = public, pg_temp
as $$
declare v_order public.cwb_japan_import_orders; v_already numeric(12,2); v_receipt public.cwb_japan_commission_receipts;
begin
  if not public.cwb_japan_is_ceo() then raise exception 'Only the C.W.B CEO may confirm commission received'; end if;
  if p_amount is null or p_amount <= 0 then raise exception 'Commission receipt amount must be greater than zero'; end if;
  select * into v_order from public.cwb_japan_import_orders where id = p_order_id for update;
  if not found then raise exception 'Vehicle order not found'; end if;
  if v_order.dhl_status <> 'Received in Burundi' or v_order.dhl_received_at is null then raise exception 'Commission is payable only after DHL documents are received in Burundi'; end if;
  select coalesce(sum(amount),0) into v_already from public.cwb_japan_commission_receipts where order_id = p_order_id;
  if round((v_already + p_amount)::numeric, 2) > v_order.commission_final then raise exception 'Receipt exceeds the outstanding C.W.B commission'; end if;
  insert into public.cwb_japan_commission_receipts(order_id, amount, reference, received_at, confirmed_by)
  values (p_order_id, round(p_amount::numeric,2), nullif(trim(coalesce(p_reference,'')),''), now(), auth.uid()) returning * into v_receipt;
  return v_receipt;
end;
$$;

revoke all on function public.cwb_japan_authorize_discount(uuid,numeric,text) from public, anon;
revoke all on function public.cwb_japan_confirm_customer_payment(uuid) from public, anon;
revoke all on function public.cwb_japan_reject_customer_payment(uuid,text) from public, anon;
revoke all on function public.cwb_japan_record_commission_receipt(uuid,numeric,text) from public, anon;
grant execute on function public.cwb_japan_authorize_discount(uuid,numeric,text) to authenticated;
grant execute on function public.cwb_japan_confirm_customer_payment(uuid) to authenticated;
grant execute on function public.cwb_japan_reject_customer_payment(uuid,text) to authenticated;
grant execute on function public.cwb_japan_record_commission_receipt(uuid,numeric,text) to authenticated;

comment on table public.cwb_japan_import_orders is 'C.W.B Japan Car Import orders; customer totals exclude C.W.B commission.';
comment on table public.cwb_japan_customer_payments is 'Customer payment claims; only CEO RPC may confirm or reject.';
comment on table public.cwb_japan_commission_receipts is 'C.W.B commission receipts, kept separate from customer payments; CEO-only RPC inserts records.';
