C.W.B JAPAN CAR IMPORT — UPLOAD AND ACTIVATION

FILES
- japan-car-import-module.js: module code.
- cwb_japan_import_setup.sql: database setup (prepared separately).

IMPORTANT
Uploading the JavaScript alone does not activate the module. The current index.html has a role-permission gate. It must be registered there, and the SQL must be run in Supabase before the module can save data.

GITHUB — UPLOAD THE JS FILE
1. Open https://github.com/Cwb2012/C.-W.-B-system-
2. Open the repository's main page.
3. Choose Add file > Upload files.
4. Upload japan-car-import-module.js to the repository ROOT (same level as index.html).
5. Commit the change to main.

INDEX.HTML — TWO REQUIRED REGISTRATIONS
Do not replace index.html with this JS file.
A. Find the `const MODULES = { ... }` object in the existing C.W.B role-permission script. Add this entry among the other module entries:
   japanImport: "japanImport",
   Keep the comma formatting consistent with the neighbouring entries.
B. Add the following script tag near the end of index.html, after the existing app scripts and before the final closing tags:
   <script src="japan-car-import-module.js"></script>
Then commit index.html. This change is necessary because the existing permission system hides modules that are not registered. CEO access is granted by the existing app logic; workers will need an assigned permission for japanImport.

SUPABASE DATABASE SETUP
The SQL file is separate and must be run in Supabase SQL Editor. Uploading the SQL file to GitHub does NOT execute it. The SQL creates new Japan Import tables and CEO-only server-side functions; it does not intentionally modify existing business tables. Review before running.

CURRENT FEATURE NOTES
- Vehicle register and status workflow: Ordered, Purchased, Shipped, Arrived in Burundi, Delivered.
- DHL documents workflow: Not dispatched, In transit, Received in Burundi.
- Customer total = vehicle price + bank fee + shipping + clearing/other costs. It EXCLUDES C.W.B commission.
- Standard commission $100 per vehicle. Commission is payable only after DHL documents are marked received in Burundi; database RPC checks this condition.
- Discount is CEO-only, $0-$100, and requires a reason when above $0.
- Customer payment claims stay PENDING until the CEO confirms/rejects them using database RPCs. Never treat a claim as confirmed payment.
- Commission receipts are separate from customer payments and CEO-only.
- This first upload version does not yet upload vehicle photos, create a full signed customer contract, or issue a formal commission receipt PDF. Those need follow-up work after the core module is connected and tested.

TEST SAFELY
Do not use a real customer record until the SQL and index.html changes are committed and tested. If the module displays “SQL setup must be installed”, the database setup has not been applied or the table access failed.
