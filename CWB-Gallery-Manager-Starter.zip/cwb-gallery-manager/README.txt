C.W.B Gallery Manager starter files

1. gallery-manager.html is a separate page. It does not replace index.html or website.html.
2. gallery-setup.sql contains initial database and storage policies. Do not run it until you have checked the Supabase Auth setup and are ready to configure policies.
3. Use only the public anon/publishable key in the HTML page. Never use the service_role/secret key.
4. To restrict gallery management to the owner, disable public sign-ups and use only your owner's Supabase Auth account.
5. The manager's upload form currently limits files to 25 MB. Use hosted links for larger videos.
6. This is a starter manager page; it is not live until added to GitHub Pages and the Supabase setup is completed.
